// =========================
// FLIPKART SELLER TOOL PRO
// Tab-wise Autofill + AI Smart Fill
// Fixed: Image tab skip, tab cross-fill bug, faster speed
// =========================

// Auth removed — tool starts directly
startTool();

// =====================================================
// MAIN TOOL
// =====================================================
function startTool() {

let capturing = false;
let capturedFields = [];
let currentSection = "all";

// =====================
// PANEL HTML
// =====================
const panel = document.createElement("div");
panel.id = "fk-tool-panel";
panel.style.cssText = `
  position:fixed;top:20px;right:20px;
  background:#1a1a2e;color:#eee;
  padding:14px;z-index:999999;
  border:1.5px solid #f7971e;border-radius:14px;
  font-family:Arial;width:280px;
  box-shadow:0 6px 24px rgba(247,151,30,0.18);
  max-height:96vh;overflow-y:auto;
`;

panel.innerHTML = `
<!-- HEADER -->
<div id="fkDragHandle" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;cursor:grab;background:#f7971e22;border-radius:8px;padding:4px 6px;">
  <span style="font-size:11px;color:#f7971e88;">⠿ drag</span>
  <span style="font-weight:bold;font-size:15px;color:#f7971e;">🛒 Flipkart Tool</span>
  <button id="fkMinBtn" style="background:#f7971e;color:#000;border:none;border-radius:50%;width:22px;height:22px;font-size:13px;cursor:pointer;font-weight:bold;">−</button>
</div>

<div id="fkBody">

<!-- ===== AI SMART FILL SECTION ===== -->
<div style="background:#0f0f1a;border:1px solid #a855f7;border-radius:10px;padding:10px;margin-bottom:10px;">
  <div style="font-size:12px;font-weight:bold;color:#a855f7;margin-bottom:6px;">🤖 AI Smart Fill</div>
  <textarea id="fkAiDesc" placeholder="Product describe karo... e.g. Surf Excel 1kg washing powder" 
    style="width:100%;padding:6px;border-radius:6px;background:#1a1a2e;color:#fff;border:1px solid #a855f744;font-size:11px;resize:vertical;min-height:52px;box-sizing:border-box;"></textarea>
  <button id="fkAiScanBtn" style="width:100%;margin-top:6px;padding:8px;border-radius:7px;border:none;background:linear-gradient(90deg,#a855f7,#7c3aed);color:#fff;font-weight:bold;font-size:12px;cursor:pointer;">🔍 Scan + AI Fill</button>
  <div id="fkAiStatus" style="font-size:10px;color:#a855f7;margin-top:4px;min-height:14px;"></div>
</div>

<!-- PROFILE NAME -->
<input id="fkProfileName" placeholder="Profile name (e.g. Dishwash 250ml)"
  style="width:100%;padding:6px;margin-bottom:6px;border:1px solid #f7971e44;border-radius:6px;background:#0f0f1a;color:#fff;box-sizing:border-box;font-size:12px;" />

<!-- AUTO TAB DETECTOR -->
<div style="font-size:11px;color:#aaa;margin-bottom:4px;">📂 Active Tab (Auto-detect):</div>
<div id="fkActiveTabDisplay" style="padding:5px 8px;background:#f7971e22;border:1px solid #f7971e;border-radius:6px;color:#f7971e;font-size:11px;font-weight:bold;margin-bottom:8px;">
  🔍 Detecting...
</div>

<!-- CAPTURE BUTTONS -->
<button id="fkStartBtn" style="width:100%;margin-bottom:5px;padding:7px;border-radius:7px;border:none;background:#f7971e;color:#000;font-weight:bold;cursor:pointer;">▶ Start Capture</button>
<button id="fkSaveBtn"  style="width:100%;margin-bottom:5px;padding:7px;border-radius:7px;border:none;background:#2ecc71;color:#000;font-weight:bold;cursor:pointer;">💾 Save Profile</button>

<hr style="border-color:#f7971e33;margin:8px 0;"/>

<!-- PROFILE LIST -->
<div style="font-size:11px;color:#aaa;margin-bottom:4px;">📋 Profiles:</div>
<select id="fkProfileList" style="width:100%;padding:6px;margin-bottom:6px;border-radius:6px;background:#0f0f1a;color:#fff;border:1px solid #f7971e44;font-size:12px;"></select>

<button id="fkDeleteBtn" style="width:100%;margin-bottom:5px;padding:6px;border-radius:6px;border:none;background:#e74c3c;color:#fff;font-weight:bold;cursor:pointer;">🗑 Delete Profile</button>
<button id="fkEditBtn"   style="width:100%;margin-bottom:5px;padding:6px;border-radius:6px;border:none;background:#3498db;color:#fff;font-weight:bold;cursor:pointer;">✏️ Edit Profile</button>
<button id="fkEditSaveBtn" style="width:100%;margin-bottom:10px;padding:6px;border-radius:6px;border:none;background:#9b59b6;color:#fff;font-weight:bold;cursor:pointer;">💾 Edit Save</button>

<hr style="border-color:#f7971e33;margin:8px 0;"/>

<!-- TAB-WISE AUTOFILL — Tab 1 (Image) removed, starts from Tab 2 -->
<div style="font-size:11px;color:#aaa;margin-bottom:4px;">⚡ Tab-wise Autofill:</div>
<div style="font-size:10px;color:#e74c3c;margin-bottom:6px;">⚠️ Tab 1 (Images) manually fill karein</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:5px;">
  <button class="fk-fill-btn" data-fill="tab2" style="padding:7px;font-size:11px;border-radius:7px;border:1px solid #f7971e;background:#f7971e22;color:#f7971e;cursor:pointer;font-weight:bold;">Tab 2 Fill</button>
  <button class="fk-fill-btn" data-fill="tab3" style="padding:7px;font-size:11px;border-radius:7px;border:1px solid #f7971e;background:#f7971e22;color:#f7971e;cursor:pointer;font-weight:bold;">Tab 3 Fill</button>
  <button class="fk-fill-btn" data-fill="tab4" style="padding:7px;font-size:11px;border-radius:7px;border:1px solid #f7971e;background:#f7971e22;color:#f7971e;cursor:pointer;font-weight:bold;">Tab 4 Fill</button>
  <button class="fk-fill-btn" data-fill="tab5" style="padding:7px;font-size:11px;border-radius:7px;border:1px solid #f7971e;background:#f7971e22;color:#f7971e;cursor:pointer;font-weight:bold;">Tab 5 Fill</button>
</div>

<button id="fkFillAllBtn" style="width:100%;padding:8px;border-radius:7px;border:none;background:linear-gradient(90deg,#f7971e,#ffd200);color:#000;font-weight:bold;font-size:13px;cursor:pointer;">🚀 Fill All Tabs Auto (2-5)</button>

<hr style="border-color:#f7971e33;margin:8px 0;"/>

<!-- ===== GROK AI AUTO FIELDS ===== -->
<div style="background:#0f0f1a;border:1px solid #22d3ee;border-radius:10px;padding:10px;margin-bottom:10px;">
  <div style="font-size:12px;font-weight:bold;color:#22d3ee;margin-bottom:6px;">⚡ AI Auto Fields (Groq)</div>
  <input id="fkProductHint" placeholder="Product name (e.g. Yash Chamak Dishwash Gel 1L)"
    style="width:100%;padding:6px;border-radius:6px;background:#1a1a2e;color:#fff;border:1px solid #22d3ee44;font-size:10px;box-sizing:border-box;margin-bottom:6px;"/>
  <button id="fkGrokFillBtn" style="width:100%;padding:8px;border-radius:7px;border:none;background:linear-gradient(90deg,#22d3ee,#0ea5e9);color:#000;font-weight:bold;font-size:12px;cursor:pointer;">🤖 AI Fill Smart Fields</button>
  <button id="fkDebugScanBtn" style="width:100%;margin-top:5px;padding:6px;border-radius:7px;border:none;background:#374151;color:#22d3ee;font-weight:bold;font-size:11px;cursor:pointer;">🔍 Debug: Scan Tag Fields</button>
  <div id="fkGrokStatus" style="font-size:10px;color:#22d3ee;margin-top:4px;min-height:14px;"></div>
</div>

<hr style="border-color:#f7971e33;margin:8px 0;"/>

<!-- STATUS -->
<div id="fkStatus" style="font-size:12px;color:#2ecc71;min-height:16px;">Idle ✅</div>
<div id="fkCount"  style="font-size:11px;color:#aaa;">Captured: 0</div>

<!-- WA BUTTON -->
<button id="fkWaBtn" style="width:100%;margin-top:8px;padding:8px;border-radius:7px;border:none;background:#25D366;color:#fff;font-weight:bold;cursor:pointer;">💬 Buy This Tool (WhatsApp)</button>

</div><!-- end fkBody -->
`;

document.body.appendChild(panel);

// =====================
// MINIMIZE
// =====================
let minimized = false;
const fkBody = document.getElementById("fkBody");
document.getElementById("fkMinBtn").onclick = () => {
    minimized = !minimized;
    fkBody.style.display = minimized ? "none" : "block";
    document.getElementById("fkMinBtn").textContent = minimized ? "+" : "−";
};

// =====================
// DRAGGABLE
// =====================
(function makeDraggable() {
    const handle = document.getElementById("fkDragHandle");
    let isDragging = false, startX, startY, startLeft, startTop;

    handle.addEventListener("mousedown", (e) => {
        if (e.target.id === "fkMinBtn") return;
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = panel.getBoundingClientRect();
        startLeft = rect.left;
        startTop = rect.top;
        handle.style.cursor = "grabbing";
        e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        let newLeft = startLeft + (e.clientX - startX);
        let newTop = startTop + (e.clientY - startY);
        newLeft = Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, newLeft));
        newTop = Math.max(0, Math.min(window.innerHeight - panel.offsetHeight, newTop));
        panel.style.right = "auto";
        panel.style.left = newLeft + "px";
        panel.style.top = newTop + "px";
    });

    document.addEventListener("mouseup", () => {
        isDragging = false;
        handle.style.cursor = "grab";
    });
})();

// =====================
// SECTION SELECT
// =====================
// AUTO TAB DETECTOR — updates currentSection automatically
function detectCurrentTab() {
    const tabSelectors = [
        '[role="tab"]',
        '[class*="tab-item"]',
        '[class*="TabItem"]',
        '[class*="step-tab"]',
        '[class*="StepLabel"]',
        '[class*="stepLabel"]',
        'ul[class*="tab"] li'
    ];

    for (const sel of tabSelectors) {
        const tabs = Array.from(document.querySelectorAll(sel));
        if (!tabs.length) continue;
        
        // Find the active/selected tab
        let activeIdx = -1;
        tabs.forEach((t, i) => {
            const cls = t.className || "";
            const aria = t.getAttribute("aria-selected");
            if (aria === "true" || cls.includes("active") || cls.includes("selected") || cls.includes("current") || cls.includes("Active") || cls.includes("Selected")) {
                activeIdx = i;
            }
        });

        if (activeIdx === -1) {
            // fallback: check which tab panel is visible
            activeIdx = tabs.findIndex(t => {
                const style = window.getComputedStyle(t);
                return style.display !== "none" && style.visibility !== "hidden" && t.offsetWidth > 0;
            });
        }

        if (activeIdx >= 1) {  // Tab 1 = image (index 0), we start from index 1
            const secMap = {1: "tab2", 2: "tab3", 3: "tab4", 4: "tab5"};
            const sec = secMap[activeIdx] || `tab${activeIdx + 1}`;
            currentSection = sec;
            const display = document.getElementById("fkActiveTabDisplay");
            if (display) display.textContent = `✅ Tab ${activeIdx + 1} → Section: ${sec}`;
            return sec;
        } else if (activeIdx === 0) {
            currentSection = "tab1_image";
            const display = document.getElementById("fkActiveTabDisplay");
            if (display) display.textContent = "⚠️ Tab 1 (Images) — Skip karo";
            return "tab1_image";
        }
    }

    // Fallback: check URL hash or page heading
    const heading = document.querySelector('[class*="step"][class*="active"] span, [class*="tab"][class*="active"]');
    if (heading) {
        const txt = heading.innerText?.toLowerCase() || "";
        if (txt.includes("image")) { currentSection = "tab1_image"; }
        else if (txt.includes("price") || txt.includes("stock") || txt.includes("shipping")) { currentSection = "tab2"; }
        else if (txt.includes("product desc")) { currentSection = "tab3"; }
        else if (txt.includes("additional")) { currentSection = "tab4"; }
        else if (txt.includes("variant")) { currentSection = "tab5"; }
        const display = document.getElementById("fkActiveTabDisplay");
        if (display) display.textContent = `✅ Detected: ${currentSection}`;
    }

    return currentSection;
}

// Run detector every second to keep in sync
setInterval(() => {
    if (capturing) detectCurrentTab();
}, 1000);

// Also run on any click (tab switches happen on click)
document.addEventListener("click", () => {
    setTimeout(detectCurrentTab, 600);
}, true);

// Run once at start
setTimeout(detectCurrentTab, 1500);

// =====================
// PROFILE MANAGEMENT
// =====================
const fkProfileList = document.getElementById("fkProfileList");
const fkStatus = document.getElementById("fkStatus");
const fkCount = document.getElementById("fkCount");

function loadProfiles() {
    const profiles = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
    fkProfileList.innerHTML = "";
    for (let name in profiles) {
        const opt = document.createElement("option");
        opt.value = name; opt.innerText = name;
        fkProfileList.appendChild(opt);
    }
}
loadProfiles();

document.getElementById("fkDeleteBtn").onclick = () => {
    const sel = fkProfileList.value;
    if (!sel) return alert("Select profile ❌");
    const p = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
    delete p[sel];
    localStorage.setItem("fk_profiles", JSON.stringify(p));
    loadProfiles();
    flashStatus("Deleted ✅", "#e74c3c");
};

// =====================
// CAPTURE START
// =====================
document.getElementById("fkStartBtn").onclick = () => {
    capturing = true;
    capturedFields = [];
    fkStatus.style.color = "#f7971e";
    flashStatus(`Capturing [${currentSection}]...`, "#f7971e");
    fkCount.innerText = "Captured: 0";
    document.getElementById("fkStartBtn").style.background = "#e74c3c";
    document.getElementById("fkStartBtn").textContent = "● Capturing...";
};

// =====================
// SAVE
// =====================
document.getElementById("fkSaveBtn").onclick = () => {
    const name = document.getElementById("fkProfileName").value.trim();
    if (!name) return alert("Profile name daalo ❌");
    const p = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
    p[name] = capturedFields.map(f => ({
        selector: f.selector,
        value: f.value,
        type: f.type || "text",
        section: f.section || "all"
    }));
    localStorage.setItem("fk_profiles", JSON.stringify(p));
    capturing = false;
    document.getElementById("fkStartBtn").style.background = "#f7971e";
    document.getElementById("fkStartBtn").textContent = "▶ Start Capture";
    flashStatus("Saved ✅", "#2ecc71");
    loadProfiles();
};

// =====================
// EDIT
// =====================
document.getElementById("fkEditBtn").onclick = () => {
    const sel = fkProfileList.value;
    if (!sel) return alert("Select profile ❌");
    const p = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
    capturing = true;
    capturedFields = (p[sel] || []).map(f => ({ ...f }));
    flashStatus(`Editing [${sel}]...`, "#3498db");
    fkCount.innerText = `Captured: ${capturedFields.length}`;
    document.getElementById("fkStartBtn").style.background = "#3498db";
    document.getElementById("fkStartBtn").textContent = "● Editing...";
};

document.getElementById("fkEditSaveBtn").onclick = () => {
    const sel = fkProfileList.value;
    if (!sel) return alert("Select profile ❌");
    const p = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
    const old = p[sel] || [];
    const merged = [...old];
    capturedFields.forEach(n => {
        const ex = merged.find(f => f.selector === n.selector && f.section === n.section);
        if (ex) { ex.value = n.value; ex.type = n.type || ex.type; }
        else merged.push({ selector: n.selector, value: n.value, type: n.type || "text", section: n.section || "all" });
    });
    p[sel] = merged;
    localStorage.setItem("fk_profiles", JSON.stringify(p));
    capturing = false;
    document.getElementById("fkStartBtn").style.background = "#f7971e";
    document.getElementById("fkStartBtn").textContent = "▶ Start Capture";
    flashStatus("Edit Saved ✅", "#9b59b6");
    fkCount.innerText = `Captured: ${merged.length}`;
    loadProfiles();
};

// =====================
// WA BUTTON
// =====================
document.getElementById("fkWaBtn").onclick = () => {
    window.open("https://wa.me/916295429762?text=Hello%20I%20need%20Flipkart%20Tool", "_blank");
};

// Groq API Key hardcoded
const fkGroqApiKey = "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";

// ============================================
// GROK AI — SMART FIELD GENERATOR
// ============================================

async function callGrok(prompt, apiKey) {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            model: "llama-3.3-70b-versatile",
            messages: [{ role: "user", content: prompt }],
            max_tokens: 800,
            temperature: 0.7
        })
    });
    if (!res.ok) throw new Error(`Groq API error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return data.choices?.[0]?.message?.content || "";
}

function setGrokStatus(msg) {
    const el = document.getElementById("fkGrokStatus");
    if (el) el.textContent = msg;
}

// Generate unique SKU ID
function generateSKU(productHint) {
    const words = productHint.toUpperCase().replace(/[^A-Z0-9 ]/g, "").split(" ").filter(Boolean);
    const prefix = words.slice(0, 2).map(w => w.substring(0, 3)).join("");
    const ts = Date.now().toString().slice(-6);
    return `${prefix}-${ts}`;
}

// Fill a multi-value tag field (Search Keywords, Key Spec, Key Features)
async function fillTagField(el, values) {
    if (!el) return;
    el.scrollIntoView({ block: "center" });
    el.click();
    el.focus();
    await sleep(400);

    for (const val of values) {
        const trimmed = val.trim();
        if (!trimmed) continue;

        // Re-focus the input every time (Flipkart loses focus after each tag)
        el.click();
        el.focus();
        await sleep(150);

        // Fill value using React setter
        await reactFill(el, trimmed);
        await sleep(300);

        // Try Enter key — multiple ways for React compatibility
        const enterDown  = new KeyboardEvent("keydown",  { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true });
        const enterPress = new KeyboardEvent("keypress", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true });
        const enterUp    = new KeyboardEvent("keyup",    { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true });
        el.dispatchEvent(enterDown);
        el.dispatchEvent(enterPress);
        el.dispatchEvent(enterUp);
        await sleep(250);

        // Also try Tab key — Flipkart tag inputs sometimes use Tab to confirm
        const tabDown  = new KeyboardEvent("keydown",  { key: "Tab", code: "Tab", keyCode: 9, which: 9, bubbles: true, cancelable: true });
        const tabUp    = new KeyboardEvent("keyup",    { key: "Tab", code: "Tab", keyCode: 9, which: 9, bubbles: true, cancelable: true });
        el.dispatchEvent(tabDown);
        el.dispatchEvent(tabUp);
        await sleep(150);

        // Also try comma as separator
        const commaDown = new KeyboardEvent("keydown",  { key: ",", code: "Comma", keyCode: 188, which: 188, bubbles: true, cancelable: true });
        const commaUp   = new KeyboardEvent("keyup",    { key: ",", code: "Comma", keyCode: 188, which: 188, bubbles: true, cancelable: true });
        el.dispatchEvent(commaDown);
        el.dispatchEvent(commaUp);
        await sleep(200);

        // Check if tag was added (value cleared = success), else try clicking an "Add" button nearby
        if (el.value.trim() !== "") {
            // Tag not added — look for add/confirm button nearby
            const parent = el.closest('[class*="tag"], [class*="Tag"], [class*="chip"], [class*="Chip"], [class*="multi"], [class*="Multi"], [class*="rti"]') || el.parentElement?.parentElement;
            if (parent) {
                const addBtn = Array.from(parent.querySelectorAll('button, [role="button"]')).find(b => !panel.contains(b));
                if (addBtn) { addBtn.click(); await sleep(200); }
            }
            // Force clear for next iteration
            await reactFill(el, "");
            await sleep(100);
        }

        await sleep(250);
    }
}

// Debug Tag Field Scanner — scrolls whole page and finds ALL RTI inputs
document.getElementById("fkDebugScanBtn").onclick = async () => {
    setGrokStatus("Scanning... (F12 Console dekho)");

    // Scroll to bottom to force-render all lazy fields
    window.scrollTo(0, 0);
    await new Promise(r => setTimeout(r, 300));
    window.scrollTo(0, document.body.scrollHeight / 2);
    await new Promise(r => setTimeout(r, 300));
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 500));
    window.scrollTo(0, 0);
    await new Promise(r => setTimeout(r, 300));

    // 1. All RTI inputs
    const rtiInputs = Array.from(document.querySelectorAll('.rti--input, [class*="rti--input"], [class*="pills-input"]')).filter(e => !panel.contains(e));
    console.log("=== ALL RTI/TAG INPUTS ===", rtiInputs.length);
    rtiInputs.forEach((el, i) => {
        // Walk up to find label
        let labelText = "", ariaId = "";
        let node = el.parentElement;
        for (let d = 0; d < 15; d++) {
            if (!node) break;
            const a = node.getAttribute?.("aria-labelledby") || "";
            if (a) { ariaId = a; }
            const lblEl = node.querySelector('[class*="AttributeItemLabelName"], [class*="LabelName"], label');
            if (lblEl && !lblEl.contains(el)) {
                labelText = lblEl.textContent?.trim() || "";
                break;
            }
            node = node.parentElement;
        }
        console.log(`[RTI ${i}] label="${labelText}" aria-labelledby="${ariaId}" placeholder="${el.placeholder}" class="${el.className}"`);
    });

    // 2. All aria-labelledby containers with inputs
    const ariaContainers = Array.from(document.querySelectorAll('[aria-labelledby]')).filter(e => !panel.contains(e));
    console.log("=== ARIA-LABELLEDBY CONTAINERS WITH INPUTS ===");
    ariaContainers.forEach(c => {
        const id = c.getAttribute("aria-labelledby");
        const inp = c.querySelector('input, .rti--input, [class*="pills-input"]');
        if (inp) console.log(`  [aria="${id}"] input.class="${inp.className}" placeholder="${inp.placeholder}"`);
    });

    // 3. All visible text inputs with their labels
    console.log("=== ALL TEXT INPUTS WITH LABELS ===");
    Array.from(document.querySelectorAll('input[type="text"], input:not([type])')).filter(e => !panel.contains(e) && e.offsetParent !== null).forEach((el, i) => {
        let lblTxt = "";
        let n = el.parentElement;
        for (let d = 0; d < 10; d++) {
            if (!n) break;
            const l = n.querySelector('[class*="AttributeItemLabelName"], [class*="LabelName"], label');
            if (l && !l.contains(el)) { lblTxt = l.textContent?.trim(); break; }
            n = n.parentElement;
        }
        console.log(`[INPUT ${i}] label="${lblTxt}" placeholder="${el.placeholder}" id="${el.id}" name="${el.name}"`);
    });

    setGrokStatus(`✅ Scan done: ${rtiInputs.length} RTI inputs. F12 Console dekho!`);
};


// =====================================================
function findFieldByHints(hints) {
    const allInputs = Array.from(document.querySelectorAll(
        'input:not([type="hidden"]):not([type="file"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]), textarea'
    )).filter(el => !panel.contains(el));

    for (const hint of hints) {
        const h = hint.toLowerCase();

        // 1. placeholder match
        let found = allInputs.find(el => el.placeholder?.toLowerCase().includes(h));
        if (found) return found;

        // 2. aria-label match
        found = allInputs.find(el => el.getAttribute("aria-label")?.toLowerCase().includes(h));
        if (found) return found;

        // 3. name attr match
        found = allInputs.find(el => el.name?.toLowerCase().includes(h));
        if (found) return found;

        // 4. Walk up DOM and look for label/span text in parent containers
        found = allInputs.find(el => {
            // Check up to 6 parent levels
            let node = el.parentElement;
            for (let i = 0; i < 6; i++) {
                if (!node) break;
                // Get text of labels/spans inside this container (not the input value)
                const labelNodes = node.querySelectorAll('label, span, div, p, li');
                for (const ln of labelNodes) {
                    // Skip if it contains the input itself (avoid getting input value)
                    if (ln.contains(el)) continue;
                    const txt = ln.childNodes[0]?.textContent?.toLowerCase() || ln.innerText?.toLowerCase() || "";
                    if (txt.includes(h)) return true;
                }
                node = node.parentElement;
            }
            return false;
        });
        if (found) return found;

        // 5. data-field or data-key attr
        found = allInputs.find(el => {
            const attrs = ["data-field", "data-key", "data-name", "data-label", "data-id", "id"];
            return attrs.some(a => el.getAttribute(a)?.toLowerCase().includes(h));
        });
        if (found) return found;
    }
    return null;
}

// Debug scanner — logs all found fields to console
function debugScanFields() {
    const allInputs = Array.from(document.querySelectorAll(
        'input:not([type="hidden"]):not([type="file"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]), textarea'
    )).filter(el => !panel.contains(el));

    console.log("=== FLIPKART FIELD SCAN ===");
    allInputs.forEach((el, i) => {
        let node = el.parentElement;
        let labelText = "";
        for (let j = 0; j < 5; j++) {
            if (!node) break;
            const labels = node.querySelectorAll("label, span");
            for (const l of labels) {
                if (l.contains(el)) continue;
                const t = l.childNodes[0]?.textContent?.trim();
                if (t && t.length > 1 && t.length < 60) { labelText = t; break; }
            }
            if (labelText) break;
            node = node.parentElement;
        }
        console.log(`[${i}] tag=${el.tagName} id="${el.id}" name="${el.name}" placeholder="${el.placeholder}" label="${labelText}" aria="${el.getAttribute("aria-label")||""}"`);
    });
    console.log("=== END SCAN ===");
}

// =====================================================
// RTI CONTAINER FILL — Flipkart ka exact structure
// aria-labelledby="keywords" → .rti--container → click → input appears
// =====================================================
async function fillRtiField(ariaId, values) {
    // Find the container by exact aria-labelledby
    const container = document.querySelector(`[aria-labelledby="${ariaId}"].rti--container`);
    if (!container || panel.contains(container)) return false;

    container.scrollIntoView({ block: "center" });
    await sleep(300);

    for (const val of values) {
        const trimmed = val.trim();
        if (!trimmed) continue;

        // Click container to reveal/focus the input
        container.click();
        await sleep(200);

        // Now find the input — it appears after click
        let inp = container.querySelector('.rti--input, input[class*="rti"], input[class*="pills"], input:not([type="hidden"])');
        if (!inp) {
            // Try parent's sibling areas
            inp = container.parentElement?.querySelector('input:not([type="hidden"])');
        }
        if (!inp) {
            console.warn(`RTI input not found for aria="${ariaId}" value="${trimmed}"`);
            continue;
        }

        inp.focus();
        await sleep(100);

        // Set value via React native setter
        const proto = window.HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(inp, trimmed);
        else inp.value = trimmed;

        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(150);

        // Press Enter to confirm tag
        ["keydown", "keypress", "keyup"].forEach(evtType => {
            inp.dispatchEvent(new KeyboardEvent(evtType, {
                key: "Enter", code: "Enter", keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            }));
        });
        await sleep(300);

        // If value not cleared (tag not added), try comma
        if (inp.value.trim() !== "") {
            ["keydown", "keyup"].forEach(evtType => {
                inp.dispatchEvent(new KeyboardEvent(evtType, {
                    key: ",", code: "Comma", keyCode: 188, which: 188,
                    bubbles: true, cancelable: true
                }));
            });
            await sleep(200);
        }

        // Force clear if still stuck
        if (inp.value.trim() !== "") {
            if (setter) setter.call(inp, "");
            else inp.value = "";
            inp.dispatchEvent(new Event("input", { bubbles: true }));
        }

        await sleep(200);
    }
    return true;
}



// Helper: get all label divs fresh from DOM
function getAllLabelDivs() {
    return Array.from(document.querySelectorAll('[class*="AttributeItemLabelName"], [class*="LabelName"]'));
}

// Helper: find plain input by label text
function findInputByLabel(labelText, labelDivs) {
    for (const lbl of (labelDivs || getAllLabelDivs())) {
        if (panel.contains(lbl)) continue;
        const txt = lbl.textContent?.trim() || '';
        if (txt === labelText || txt.startsWith(labelText)) {
            let node = lbl.parentElement;
            for (let d = 0; d < 8; d++) {
                if (!node) break;
                const inp = node.querySelector('input[type="text"]:not([disabled]):not([readonly]), input[type=""]:not([disabled])');
                if (inp && !panel.contains(inp)) return inp;
                node = node.parentElement;
            }
        }
    }
    return null;
}

// Helper: click Flipkart tab by index and wait for DOM change
async function clickFlipkartTab(tabIdx) {
    const tabSelectors = [
        '[role="tab"]', '[class*="TabItem"]', '[class*="tab-item"]',
        '[class*="StepLabel"]', '[class*="stepLabel"]', 'ul[class*="tab"] li'
    ];
    for (const sel of tabSelectors) {
        const tabs = document.querySelectorAll(sel);
        if (tabs.length > tabIdx) {
            const prevCount = document.querySelectorAll('input:not([type="hidden"]):not([type="file"]), textarea').length;
            tabs[tabIdx].click();
            let waited = 0;
            while (waited < 3000) {
                await sleep(200); waited += 200;
                const newCount = document.querySelectorAll('input:not([type="hidden"]):not([type="file"]), textarea').length;
                if (newCount !== prevCount) break;
            }
            await sleep(700);
            return true;
        }
    }
    // Fallback: Save & Next
    const nextBtn = Array.from(document.querySelectorAll('button')).find(b =>
        !panel.contains(b) && /save\s*&?\s*next|next/i.test(b.innerText?.trim())
    );
    if (nextBtn) { nextBtn.click(); await sleep(1800); return true; }
    return false;
}

document.getElementById("fkGrokFillBtn").onclick = async () => {
    const apiKey = fkGroqApiKey;
    const productHint = document.getElementById("fkProductHint").value.trim();

    if (!productHint) return alert("Product name daalo ❌");

    const btn = document.getElementById("fkGrokFillBtn");
    btn.disabled = true;
    btn.textContent = "⏳ Generating...";
    setGrokStatus("AI se data le raha hai...");

    try {
        // === STEP 1: AI se data generate ===
        const prompt = `You are a Flipkart seller assistant. Generate the following fields for this product listing on Flipkart India:

Product: "${productHint}"

Return ONLY a valid JSON object (no markdown, no explanation) with these exact keys:
{
  "model_name": "product model name (short, 3-6 words)",
  "search_keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5", "keyword6", "keyword7", "keyword8"],
  "key_specs": ["spec1", "spec2", "spec3", "spec4", "spec5"],
  "key_features": ["feature1", "feature2", "feature3", "feature4", "feature5"],
  "description": "A 3-4 sentence product description in English suitable for Flipkart listing. Mention key benefits, usage, and quality."
}

Rules:
- search_keywords: 8 relevant Hindi+English mixed keywords buyers would search
- key_specs: 5 technical specs (e.g. Volume: 1L, Fragrance: Lemon, etc.)
- key_features: 5 bullet point features (benefits, what makes it good)
- description: 60-80 words, professional seller tone`;

        setGrokStatus("⏳ AI response aa rahi hai...");
        const raw = await callGrok(prompt, apiKey);

        let aiData;
        try {
            const clean = raw.replace(/```json|```/g, "").trim();
            aiData = JSON.parse(clean);
        } catch(e) {
            const match = raw.match(/\{[\s\S]+\}/);
            if (match) aiData = JSON.parse(match[0]);
            else throw new Error("JSON parse failed: " + raw.substring(0, 100));
        }

        setGrokStatus("✅ Data mila! Fields fill ho rahi hain...");
        let filled = 0;
        const results = [];

        // ============================================================
        // Flipkart tab structure (confirmed from debug):
        // Tab 1 (idx 0) = Images — skip
        // Tab 2 (idx 1) = Price/Stock — SKU ID yahan hoga
        // Tab 3 (idx 2) = Product Description — Model Name, Description yahan
        // Tab 4 (idx 3) = Additional/General — Search Keywords, Key Spec, Key Features yahan
        // ============================================================

        // === TAB 2: SKU ID ===
        setGrokStatus("📂 Tab 2 → SKU ID fill kar raha hai...");
        await clickFlipkartTab(1);

        let labelDivs = getAllLabelDivs();
        let skuEl = findInputByLabel("Seller SKU ID", labelDivs) || findInputByLabel("SKU ID", labelDivs);
        if (skuEl) {
            await reactFill(skuEl, generateSKU(productHint));
            filled++; results.push("SKU ✅");
        } else {
            results.push("SKU ❌");
        }
        await sleep(400);

        // === TAB 3: Model Name + Description ===
        setGrokStatus("📂 Tab 3 → Model Name + Description...");
        await clickFlipkartTab(2);
        await sleep(500);

        labelDivs = getAllLabelDivs();

        // Model Name
        let modelEl = findInputByLabel("Model Name", labelDivs);
        if (!modelEl) {
            // Fallback: title_attr
            const ta = document.querySelector('.title_attr');
            if (ta) {
                let n = ta.parentElement;
                for (let d = 0; d < 6; d++) {
                    if (!n) break;
                    const inp = n.querySelector('input[type="text"]:not([disabled])');
                    if (inp && !panel.contains(inp)) { modelEl = inp; break; }
                    n = n.parentElement;
                }
            }
        }
        if (modelEl && aiData.model_name) {
            await reactFill(modelEl, aiData.model_name);
            filled++; results.push("Model ✅");
        } else results.push("Model ❌");
        await sleep(400);

        // Description — try Tab 3 first
        let descEl = document.querySelector('textarea[maxlength="5000"], textarea[class*="StyledTextArea"], textarea[class*="styledTextArea"]');
        if (!descEl) {
            for (const lbl of labelDivs) {
                if (panel.contains(lbl)) continue;
                if ((lbl.textContent?.trim() || '').toLowerCase() === 'description') {
                    let n = lbl.parentElement;
                    for (let d = 0; d < 6; d++) {
                        if (!n) break;
                        const ta = n.querySelector('textarea');
                        if (ta && !panel.contains(ta)) { descEl = ta; break; }
                        n = n.parentElement;
                    }
                    if (descEl) break;
                }
            }
        }
        let descFilled = false;
        if (descEl && aiData.description) {
            await reactFill(descEl, aiData.description);
            filled++; results.push("Desc ✅"); descFilled = true;
        }
        await sleep(400);

        // === TAB 4: Search Keywords, Key Spec, Key Features (+ Description fallback) ===
        setGrokStatus("📂 Tab 4 → Keywords / Specs / Features...");
        await clickFlipkartTab(3);
        await sleep(1200); // RTI widgets ko fully load hone do

        // Description fallback (agar tab 3 mein nahi mila)
        if (!descFilled) {
            let descEl4 = document.querySelector('textarea[maxlength="5000"], textarea[class*="StyledTextArea"]');
            if (descEl4 && aiData.description && !panel.contains(descEl4)) {
                await reactFill(descEl4, aiData.description);
                filled++; results.push("Desc ✅");
                descFilled = true;
            }
        }

        // --- Search Keywords --- aria-labelledby="keywords" (confirmed from HTML)
        setGrokStatus("Search Keywords fill ho rahi hain...");
        const kwOk = await fillRtiField("keywords", aiData.search_keywords || []);
        if (kwOk) { filled++; results.push("Keywords ✅"); }
        else results.push("Keywords ❌");
        await sleep(500);

        // --- Key Spec --- aria-labelledby="key_spec" (confirmed from HTML)
        setGrokStatus("Key Spec fill ho rahi hain...");
        const specOk = await fillRtiField("key_spec", aiData.key_specs || []);
        if (specOk) { filled++; results.push("Specs ✅"); }
        else results.push("Specs ❌");
        await sleep(500);

        // --- Key Features --- aria-labelledby="key_features" (confirmed from HTML)
        setGrokStatus("Key Features fill ho rahi hain...");
        const featOk = await fillRtiField("key_features", aiData.key_features || []);
        if (featOk) { filled++; results.push("Features ✅"); }
        else results.push("Features ❌");
        await sleep(500);

        const summary = results.join(" | ");
        setGrokStatus(`✅ ${filled}/6: ${summary}`);
        flashStatus(`🤖 AI: ${filled}/6 filled ✅`, "#22d3ee");

    } catch(err) {
        console.error(err);
        setGrokStatus("❌ Error: " + err.message);
        flashStatus("❌ AI error!", "#e74c3c");
    }

    btn.disabled = false;
    btn.textContent = "🤖 AI Fill Smart Fields";
};

// =====================================================
// 🤖 AI SMART FILL — CORE FEATURE
// =====================================================

function scanAllPageFields() {
    const fields = [];
    const seen = new Set();

    const allEls = document.querySelectorAll('input:not([type="hidden"]):not([type="file"]):not([type="submit"]):not([type="button"]), textarea, select');

    allEls.forEach(el => {
        if (panel.contains(el)) return;
        if (el.offsetParent === null && el.offsetWidth === 0) return;

        const selector = getSelector(el);
        if (!selector || seen.has(selector)) return;
        seen.add(selector);

        const label = getFieldLabel(el);

        fields.push({
            selector,
            label: label || "",
            placeholder: el.placeholder || "",
            type: el.tagName === "SELECT" ? "dropdown" : "text",
            currentValue: el.value || "",
            options: el.tagName === "SELECT" ? Array.from(el.options).map(o => o.text.trim()).filter(Boolean) : []
        });
    });

    const comboboxes = document.querySelectorAll('[role="combobox"], [role="listbox"] ~ input, [aria-haspopup="listbox"]');
    comboboxes.forEach(el => {
        if (panel.contains(el)) return;
        const selector = getSelector(el);
        if (!selector || seen.has(selector)) return;
        seen.add(selector);
        const label = getFieldLabel(el);
        fields.push({
            selector,
            label: label || "",
            placeholder: el.getAttribute("placeholder") || el.getAttribute("aria-label") || "",
            type: "dropdown",
            currentValue: el.value || el.innerText || "",
            options: []
        });
    });

    return fields;
}

function getFieldLabel(el) {
    if (el.id) {
        const lbl = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
        if (lbl) return lbl.innerText.trim();
    }
    const parentLabel = el.closest("label");
    if (parentLabel) return parentLabel.innerText.replace(el.value, "").trim();
    if (el.getAttribute("aria-label")) return el.getAttribute("aria-label");
    const lblId = el.getAttribute("aria-labelledby");
    if (lblId) {
        const lblEl = document.getElementById(lblId);
        if (lblEl) return lblEl.innerText.trim();
    }
    const prev = el.previousElementSibling;
    if (prev && ["LABEL","SPAN","DIV","P","LI"].includes(prev.tagName)) {
        const t = prev.innerText.trim();
        if (t.length < 80) return t;
    }
    const parentDiv = el.closest('[class*="field"], [class*="Field"], [class*="form"], [class*="Form"], [class*="input"], [class*="Input"]');
    if (parentDiv) {
        const labelInParent = parentDiv.querySelector('label, [class*="label"], [class*="Label"]');
        if (labelInParent && !labelInParent.contains(el)) return labelInParent.innerText.trim();
    }
    return el.placeholder || el.name || "";
}

async function callAI(userDesc, fields) {
    const fieldList = fields.map((f, i) =>
        `${i+1}. label="${f.label}" placeholder="${f.placeholder}" type=${f.type}${f.options.length ? " options=[" + f.options.slice(0,8).join(", ") + "]" : ""}`
    ).join("\n");

    const prompt = `You are filling a Flipkart seller product listing form.

User described the product as: "${userDesc}"

Below are ALL the form fields found on the current page (label, placeholder, type, dropdown options if any):
${fieldList}

Instructions:
- Based on the product description, fill appropriate values for EACH field.
- For dropdown fields, pick the BEST MATCHING value from the given options list.
- For text fields, generate a suitable value based on field label and product.
- If a field is not relevant (like image upload, checkbox), set value to "SKIP".
- Common Flipkart fields: Product Title, Brand, MRP, Selling Price, Stock/Quantity, HSN Code, Description, Bullet Points, Weight, Dimensions, Category, etc.
- For HSN code: guess based on product category.
- For description/bullet points: write proper Hindi/English seller-style content.
- Return ONLY a JSON array (no markdown, no explanation), like:
[{"index":1,"value":"Surf Excel Matic Front Load Detergent Powder"},{"index":2,"value":"Surf Excel"},...]

If you cannot determine a value, use "SKIP".`;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: "claude-sonnet-4-20250514",
            max_tokens: 1000,
            messages: [{ role: "user", content: prompt }]
        })
    });

    const data = await res.json();
    const text = data.content?.map(c => c.text || "").join("") || "";
    const clean = text.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
}

async function fillFieldsWithAI(fields, aiValues) {
    const valueMap = {};
    aiValues.forEach(v => { valueMap[v.index] = v.value; });

    let filled = 0;
    for (let i = 0; i < fields.length; i++) {
        const f = fields[i];
        const val = valueMap[i + 1];
        if (!val || val === "SKIP") continue;

        let el = null;
        try {
            const all = document.querySelectorAll(f.selector);
            el = all[0] || null;
        } catch (e) {
            const idMatch = f.selector.match(/^#(.+)$/);
            if (idMatch) el = document.getElementById(idMatch[1].replace(/\\(.)/g, "$1"));
        }
        if (!el) continue;

        el.scrollIntoView({ block: "center" });
        await sleep(80);

        if (f.type === "dropdown") {
            await fillDropdown(el, val);
        } else {
            await reactFill(el, val);
        }
        filled++;
        await sleep(120);

        setAiStatus(`Filling... ${filled} fields done`);
    }
    return filled;
}

document.getElementById("fkAiScanBtn").onclick = async () => {
    const desc = document.getElementById("fkAiDesc").value.trim();
    if (!desc) return alert("Product describe karo pehle ❌");

    const btn = document.getElementById("fkAiScanBtn");
    btn.disabled = true;
    btn.textContent = "⏳ Scanning...";
    setAiStatus("Page fields scan ho rahi hain...");

    try {
        const fields = scanAllPageFields();
        setAiStatus(`${fields.length} fields mili. AI se values le raha hai...`);

        if (!fields.length) {
            setAiStatus("❌ Koi field nahi mili. Page fully load ho gayi hai?");
            btn.disabled = false;
            btn.textContent = "🔍 Scan + AI Fill";
            return;
        }

        const aiValues = await callAI(desc, fields);
        setAiStatus(`AI ne ${aiValues.filter(v => v.value !== "SKIP").length} fields fill kari. Apply ho raha hai...`);

        const filled = await fillFieldsWithAI(fields, aiValues);
        setAiStatus(`✅ ${filled} fields fill ho gayi!`);
        flashStatus(`🤖 AI ne ${filled} fields fill kari ✅`, "#a855f7");

    } catch (err) {
        console.error(err);
        setAiStatus("❌ Error: " + err.message);
    }

    btn.disabled = false;
    btn.textContent = "🔍 Scan + AI Fill";
};

function setAiStatus(msg) {
    const el = document.getElementById("fkAiStatus");
    if (el) el.textContent = msg;
}

// ==============================================
// TAB-WISE AUTOFILL LOGIC — FIXED VERSION
// ==============================================

// ✅ FIX: Tab index map — Tab 1 = Image (skip), Tab 2 = Price/Stock, etc.
// Flipkart tabs: [0]=Image, [1]=Price+Stock, [2]=Product Desc, [3]=Additional Desc, [4]=Variant
// Our section keys: tab2=idx1, tab3=idx2, tab4=idx3, tab5=idx4

const TAB_INDEX_MAP = {
    tab2: 1,
    tab3: 2,
    tab4: 3,
    tab5: 4
};

// ✅ FIX: Track which actual DOM tab index we're on to prevent cross-fill
let _currentActiveTabIndex = -1;

async function clickTab(tabKey) {
    const idx = TAB_INDEX_MAP[tabKey] ?? 1;

    // METHOD 1: Try clicking the actual tab header
    const tabSelectors = [
        '[role="tab"]',
        '[class*="tab-item"]',
        '[class*="TabItem"]',
        '[class*="step-tab"]',
        'ul[class*="tab"] li',
        '[class*="wizard"] [class*="step"]',
        '[class*="StepLabel"]',
        '[class*="stepLabel"]'
    ];

    for (const sel of tabSelectors) {
        const tabs = document.querySelectorAll(sel);
        if (tabs.length > idx) {
            const prevCount = document.querySelectorAll('input:not([type="hidden"]):not([type="file"]), textarea, select').length;
            tabs[idx].click();
            _currentActiveTabIndex = idx;
            await waitForTabContent(prevCount, 2000);
            await sleep(400);
            return true;
        }
    }

    // METHOD 2: Use "Save & Next" button - Flipkart main yahi kaam karta hai
    const nextTexts = ["save & next", "next", "save and next", "continue"];
    const allBtns = Array.from(document.querySelectorAll('button, [role="button"]'));
    const nextBtn = allBtns.find(b => {
        if (panel.contains(b)) return false;
        const t = b.innerText?.trim().toLowerCase();
        return nextTexts.some(n => t === n || t.includes(n));
    });

    if (nextBtn) {
        const prevCount = document.querySelectorAll('input:not([type="hidden"]):not([type="file"]), textarea, select').length;
        nextBtn.click();
        await waitForTabContent(prevCount, 2500);
        await sleep(400);
        _currentActiveTabIndex = idx;
        return true;
    }

    await sleep(800);
    return false;
}

// Wait until page field count changes = new tab loaded
async function waitForTabContent(previousCount, maxWait = 3000) {
    const start = Date.now();
    while (Date.now() - start < maxWait) {
        const n = document.querySelectorAll('input:not([type="hidden"]):not([type="file"]), textarea, select').length;
        if (n !== previousCount) return true;
        await sleep(150);
    }
    return false;
}

// ✅ FIX: fillSection now STRICTLY only fills fields tagged with that section
// Fields tagged "all" are also filled but only ONCE per tab (tracked via filled set)
async function fillSection(data, sectionKey) {
    // STRICT: only fill fields that were captured on this exact tab
    // "all" section = legacy, treated as tab2 only
    let sectionData = data.filter(f => {
        if (f.section === sectionKey) return true;
        if (sectionKey === "tab2" && f.section === "all") return true;
        return false;
    });

    if (!sectionData.length) {
        flashStatus(`No data for ${sectionKey}`, "#aaa");
        return;
    }
    flashStatus(`Filling ${sectionKey}...`, "#f7971e");

    // ✅ FIX: Use a per-run selector counter to handle repeated selectors correctly
    const selectorIndexMap = {};

    for (const f of sectionData) {
        if (selectorIndexMap[f.selector] === undefined) selectorIndexMap[f.selector] = 0;
        const targetIndex = selectorIndexMap[f.selector];
        selectorIndexMap[f.selector]++;

        let el = null;
        for (let i = 0; i < 8; i++) {
            try {
                const all = document.querySelectorAll(f.selector);
                el = all[targetIndex] || all[0] || null;
            } catch (e) {
                const idMatch = f.selector.match(/^#(.+)$/);
                if (idMatch) el = document.getElementById(idMatch[1].replace(/\\(.)/g, "$1"));
            }
            if (el) break;
            await sleep(200);
        }
        if (!el) { console.log("Not found:", f.selector); continue; }

        el.scrollIntoView({ block: "center" });
        await sleep(80);  // ✅ Faster: was 150ms

        if (f.type === "dropdown") {
            await fillDropdown(el, f.value);
        } else {
            await reactFill(el, f.value);
        }

        await sleep(200);  // ✅ Faster: was 350ms

        const nextSame = sectionData.slice(sectionData.indexOf(f) + 1).filter(x => x.selector === f.selector).length;
        if (nextSame > 0) {
            const addBtns = Array.from(document.querySelectorAll('button, span[role="button"], a')).filter(b => {
                const t = b.innerText?.trim().toLowerCase();
                return t === "+" || t === "add" || t.includes("add more") || t.includes("add variant") || t.includes("add size") || t.includes("add row");
            });
            if (addBtns.length) { addBtns[addBtns.length - 1].click(); await sleep(500); }
        }
    }
    flashStatus(`${sectionKey} Done ✅`, "#2ecc71");
}

document.querySelectorAll(".fk-fill-btn").forEach(btn => {
    btn.onclick = async () => {
        const fillKey = btn.dataset.fill;
        const sel = fkProfileList.value;
        if (!sel) return alert("Select profile ❌");
        const p = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
        const data = p[sel];
        if (!data || !data.length) return alert("Profile empty ❌");

        await clickTab(fillKey);
        await sleep(600);
        await fillSection(data, fillKey);
    };
});

// ✅ FIX: Fill All only loops tab2 to tab5 (skips tab1/Image entirely)
document.getElementById("fkFillAllBtn").onclick = async () => {
    const sel = fkProfileList.value;
    if (!sel) return alert("Select profile ❌");
    const p = JSON.parse(localStorage.getItem("fk_profiles") || "{}");
    const data = p[sel];
    if (!data || !data.length) return alert("Profile empty ❌");

    // ✅ Tab 1 (Image) is ALWAYS skipped
    const sections = ["tab2", "tab3", "tab4", "tab5"];

    for (let i = 0; i < sections.length; i++) {
        const sec = sections[i];

        // Check if there is any data for this tab
        const hasData = data.some(f => f.section === sec || (sec === "tab2" && f.section === "all"));
        if (!hasData) {
            console.log(`No data for ${sec}, trying to advance tab anyway...`);
            // Still advance to next tab even if no data (so sequence stays correct)
            if (i < sections.length - 1) {
                flashStatus(`⏭ Skipping ${sec} (no data)...`, "#aaa");
                await clickTab(sec);
                await sleep(600);
            }
            continue;
        }

        flashStatus(`⏳ Switching to ${sec}...`, "#f7971e");

        // Click the tab and wait for content to actually change
        await clickTab(sec);

        // Extra buffer — let React re-render settle completely
        await sleep(700);

        // Now fill only this tab's fields
        await fillSection(data, sec);

        // Buffer between tabs to prevent state bleed
        await sleep(500);
    }
    flashStatus("🚀 All Tabs Filled!", "#2ecc71");
};

// =====================
// DROPDOWN FILL HELPER
// =====================
async function fillDropdown(el, value) {
    el.click();
    el.focus();
    await sleep(400);  // ✅ Faster: was 600ms

    const optSelectors = [
        '[role="option"]',
        '[class*="option"]',
        '[class*="MenuItem"]',
        '[class*="menu-item"]',
        '[class*="dropdown-item"]',
        'li[class*="item"]',
        '[data-value]'
    ];

    for (const sel of optSelectors) {
        const opts = Array.from(document.querySelectorAll(sel));
        let match = opts.find(o => o.innerText?.trim().toLowerCase() === value.toLowerCase());
        if (!match) match = opts.find(o => o.innerText?.trim().toLowerCase().includes(value.toLowerCase()));
        if (!match) match = opts.find(o => o.innerText?.trim().toLowerCase().startsWith(value.toLowerCase()));
        if (match) {
            match.scrollIntoView({ block: "center" });
            await sleep(80);
            match.click();
            return;
        }
    }

    if (el.tagName === "SELECT") {
        const opts = Array.from(el.options);
        let match = opts.find(o => o.text.trim().toLowerCase() === value.toLowerCase());
        if (!match) match = opts.find(o => o.text.toLowerCase().includes(value.toLowerCase()));
        if (match) {
            el.value = match.value;
            el.dispatchEvent(new Event("change", { bubbles: true }));
        }
    }
}

// =====================
// REACT FILL HELPER
// =====================
async function reactFill(el, value) {
    el.focus();
    el.click();
    await sleep(20);  // ✅ Faster: was 30ms
    const proto = el.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, value);
    else el.value = value;

    ["input", "change"].forEach(evt => el.dispatchEvent(new Event(evt, { bubbles: true })));
    ["keydown", "keypress", "keyup"].forEach(k => el.dispatchEvent(new KeyboardEvent(k, { bubbles: true })));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
}

// ==============================================
// INSTANT CAPTURE
// ==============================================

function handleTextCapture(e) {
    if (!capturing) return;
    const el = e.target;
    if (!el || !["INPUT", "TEXTAREA"].includes(el.tagName)) return;
    if (["checkbox", "radio", "file", "hidden"].includes(el.type)) return;
    if (panel.contains(el)) return;

    const selector = getSelector(el);
    if (!selector) return;
    const val = el.value.trim();
    if (!val) return;

    const existing = capturedFields.find(f => f.selector === selector && f._el === el);
    if (existing) {
        existing.value = val;
    } else {
        capturedFields.push({ selector, value: val, type: "text", section: currentSection, _el: el });
    }
    fkCount.innerText = `Captured: ${capturedFields.length}`;
    flashStatus("✅ Text Captured!", "#2ecc71");
}

document.addEventListener("input",    handleTextCapture, true);
document.addEventListener("focusout", handleTextCapture, true);

document.addEventListener("change", (e) => {
    if (!capturing) return;
    if (panel.contains(e.target)) return;
    const el = e.target;
    if (el.tagName === "SELECT") {
        const selector = getSelector(el);
        if (!selector) return;
        const val = el.options[el.selectedIndex]?.text?.trim() || el.value?.trim();
        if (!val) return;
        const existing = capturedFields.find(f => f.selector === selector);
        if (existing) { existing.value = val; }
        else capturedFields.push({ selector, value: val, type: "dropdown", section: currentSection });
        fkCount.innerText = `Captured: ${capturedFields.length}`;
        flashStatus("✅ Dropdown Captured!", "#2ecc71");
    }
}, true);

document.addEventListener("click", (e) => {
    if (!capturing) return;
    if (panel.contains(e.target)) return;
    const el = e.target;

    const option = el.closest('[role="option"]') ||
                   el.closest('[class*="option"]') ||
                   el.closest('[class*="MenuItem"]') ||
                   el.closest('[class*="menu-item"]') ||
                   el.closest('[class*="dropdown-item"]') ||
                   el.closest('[data-value]');

    if (option) {
        captureDropdownOption(option);
        return;
    }

    if (el.tagName === "INPUT" && el.readOnly) {
        setTimeout(() => {
            const selector = getSelector(el);
            if (!selector) return;
            const val = el.value?.trim();
            if (!val) return;
            const existing = capturedFields.find(f => f.selector === selector && f._el === el);
            if (existing) { existing.value = val; }
            else capturedFields.push({ selector, value: val, type: "dropdown", section: currentSection, _el: el });
            fkCount.innerText = `Captured: ${capturedFields.length}`;
            flashStatus("✅ Dropdown Captured!", "#2ecc71");
        }, 500);
    }
}, true);

const dropObs = new MutationObserver(() => {
    if (!capturing) return;
    document.querySelectorAll('[aria-selected="true"]').forEach(opt => {
        if (!panel.contains(opt)) captureDropdownOption(opt);
    });
});
dropObs.observe(document.body, {
    subtree: true, attributes: true,
    attributeFilter: ["aria-selected", "aria-expanded", "class"]
});

function captureDropdownOption(optEl) {
    const val = optEl.innerText?.trim() || optEl.getAttribute("data-value");
    if (!val) return;

    let triggerEl = null;
    const listbox = optEl.closest('[role="listbox"]');
    if (listbox) {
        const lbId = listbox.id;
        if (lbId) triggerEl = document.querySelector(`[aria-owns="${lbId}"], [aria-controls="${lbId}"]`);
        if (!triggerEl) {
            const parent = listbox.parentElement;
            triggerEl = parent?.querySelector("input") || parent?.previousElementSibling?.querySelector("input") || parent?.previousElementSibling;
        }
    }
    if (!triggerEl) {
        const focused = document.activeElement;
        if (focused && !panel.contains(focused)) triggerEl = focused;
    }

    const selector = triggerEl ? getSelector(triggerEl) : null;
    if (!selector) return;

    const existing = capturedFields.find(f => f.selector === selector);
    if (existing) { existing.value = val; }
    else capturedFields.push({ selector, value: val, type: "dropdown", section: currentSection, _el: triggerEl });

    fkCount.innerText = `Captured: ${capturedFields.length}`;
    flashStatus("✅ Dropdown Captured!", "#2ecc71");
}

// =====================
// HELPERS
// =====================
function getSelector(el) {
    if (!el) return null;
    if (el.id && !el.id.match(/^(:r|mui-|\d)/)) return `#${CSS.escape(el.id)}`;
    if (el.name) return `[name="${el.name}"]`;
    if (el.getAttribute?.("aria-label")) return `[aria-label="${el.getAttribute("aria-label")}"]`;
    if (el.placeholder) return `[placeholder="${CSS.escape(el.placeholder)}"]`;
    if (el.className && typeof el.className === "string") {
        const cls = el.className.trim().split(/\s+/)[0];
        if (cls && !cls.includes(":") && !cls.includes("(")) return `${el.tagName.toLowerCase()}.${cls}`;
    }
    return null;
}

let flashTimer = null;
function flashStatus(msg, color = "#2ecc71") {
    fkStatus.innerText = msg;
    fkStatus.style.color = color;
    if (flashTimer) clearTimeout(flashTimer);
    flashTimer = setTimeout(() => {
        fkStatus.innerText = capturing ? "● Capturing..." : "Idle ✅";
        fkStatus.style.color = capturing ? "#f7971e" : "#2ecc71";
    }, 1500);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

} // end startTool
