// Auth removed — popup opens directly
