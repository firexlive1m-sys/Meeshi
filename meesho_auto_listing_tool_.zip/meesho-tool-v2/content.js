// =========================
// MEESHO TOOL (INSTANT CAPTURE - ALL FIELDS) v3 FIXED
// =========================

// Auth removed — tool starts directly
startTool();

// =========================
// MAIN TOOL
// =========================
function startTool() {

let capturing = false;
let capturedFields = [];

const panel = document.createElement("div");
panel.style.cssText = "position:fixed;top:20px;right:20px;background:#fff;color:#000;padding:15px;z-index:999999;border:1px solid #ddd;border-radius:12px;font-family:Arial;width:260px;box-shadow:0 4px 12px rgba(0,0,0,0.2);max-height:95vh;overflow-y:auto;";

panel.innerHTML = `
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
  <h3 style="margin:0;">⚡ Meesho Tool</h3>
  <button id="minimizeBtn" title="Minimize" style="background:#f55036;color:white;border:none;border-radius:50%;width:24px;height:24px;font-size:14px;cursor:pointer;line-height:1;display:flex;align-items:center;justify-content:center;flex-shrink:0;">−</button>
</div>

<input id="profileName" placeholder="Profile name"
style="width:100%;padding:6px;margin-bottom:6px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box;" />

<button id="saveBtn" style="width:100%;margin-bottom:5px;">Save Profile</button>
<button id="editBtn" style="width:100%;margin-bottom:5px;">Edit</button>
<button id="editSaveBtn" style="width:100%;margin-bottom:10px;">Edit Save</button>

<select id="profileList" style="width:100%;padding:6px;margin-bottom:8px;border-radius:6px;"></select>
<button id="deleteBtn" style="width:100%;margin-bottom:10px;background:#ff4d4d;color:white;border:none;padding:6px;border-radius:6px;">Delete</button>

<button id="startBtn" style="width:100%;margin-bottom:5px;">Start Capture</button>
<button id="runBtn" style="width:100%;background:#4CAF50;color:white;border:none;padding:6px;border-radius:6px;">Autofill</button>

<!-- ===== SEO AI SECTION ===== -->
<div style="margin-top:12px;border-top:2px solid #f55036;padding-top:10px;">
  <div style="font-size:12px;font-weight:bold;margin-bottom:2px;color:#f55036;">🤖 AI SEO Auto Generate</div>
  <div style="font-size:10px;color:#43a047;margin-bottom:8px;font-weight:bold;">✅ 100% FREE - No Credit Card</div>

  <label style="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:12px;cursor:pointer;user-select:none;">
    <input type="checkbox" id="seoTitleCheck" style="width:15px;height:15px;cursor:pointer;accent-color:#f55036;" />
    <span>✏️ Auto Generate Title (SEO)</span>
  </label>

  <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:12px;cursor:pointer;user-select:none;">
    <input type="checkbox" id="seoDescCheck" style="width:15px;height:15px;cursor:pointer;accent-color:#f55036;" />
    <span>📝 Auto Generate Description (SEO)</span>
  </label>

  <input id="seoBrand" placeholder="🏷️ Brand name (optional) — e.g. Yash Chamak"
    style="width:100%;padding:6px;border:1px solid #ffccbc;border-radius:6px;box-sizing:border-box;font-size:12px;margin-bottom:6px;" />

  <input id="seoKeyword" placeholder="Product keyword — e.g. dishwash 250 x 3"
    style="width:100%;padding:6px;border:1px solid #ffccbc;border-radius:6px;box-sizing:border-box;font-size:12px;margin-bottom:6px;" />

  <button id="seoGenerateBtn"
    style="width:100%;background:#f55036;color:white;border:none;padding:8px;border-radius:6px;font-size:12px;cursor:pointer;font-weight:bold;">
    ✨ Generate SEO Content
  </button>

  <div id="seoStatus" style="margin-top:6px;font-size:11px;color:#555;min-height:16px;word-break:break-word;line-height:1.4;"></div>
</div>
<!-- ===== END SEO SECTION ===== -->

<div id="status" style="margin-top:10px;font-size:12px;">Idle</div>
<div id="countBox" style="font-size:12px;">Captured: 0</div>
<button id="waBtn" style="width:100%;margin-top:10px;background:#25D366;color:white;border:none;padding:8px;border-radius:6px;font-weight:bold;">
💬 for buy this tool WhatsApp
</button>
`;

document.body.appendChild(panel);

// ===== MINIMIZE LOGIC =====
const panelBody = document.createElement("div");
panelBody.id = "panelBody";
const header = panel.firstElementChild;
while (panel.children.length > 1) {
    panelBody.appendChild(panel.children[1]);
}
panel.appendChild(panelBody);

let isMinimized = false;
document.getElementById("minimizeBtn").onclick = () => {
    isMinimized = !isMinimized;
    panelBody.style.display = isMinimized ? "none" : "block";
    panel.style.overflowY = isMinimized ? "hidden" : "auto";
    panel.style.maxHeight = isMinimized ? "none" : "95vh";
    document.getElementById("minimizeBtn").textContent = isMinimized ? "+" : "−";
    document.getElementById("minimizeBtn").title = isMinimized ? "Restore" : "Minimize";
};
// ===== END MINIMIZE LOGIC =====

const statusBox = document.getElementById("status");
const profileList = document.getElementById("profileList");
const countBox = document.getElementById("countBox");
const startBtn = document.getElementById("startBtn");

document.getElementById("waBtn").onclick = () => {
    window.open("https://wa.me/919213631880?text=Hello%20I%20need%20this%20tool", "_blank");
};

function loadProfiles() {
    const profiles = JSON.parse(localStorage.getItem("meesho_profiles") || "{}");
    profileList.innerHTML = "";
    for (let name in profiles) {
        const opt = document.createElement("option");
        opt.value = name; opt.innerText = name;
        profileList.appendChild(opt);
    }
}
loadProfiles();

document.getElementById("deleteBtn").onclick = () => {
    const selected = profileList.value;
    if (!selected) return alert("Select profile ❌");
    const profiles = JSON.parse(localStorage.getItem("meesho_profiles") || "{}");
    delete profiles[selected];
    localStorage.setItem("meesho_profiles", JSON.stringify(profiles));
    loadProfiles();
    alert("Deleted ✅");
};

startBtn.onclick = () => {
    capturing = true; capturedFields = [];
    statusBox.innerText = "Capturing...";
    countBox.innerText = "Captured: 0";
    startBtn.innerText = "● Capturing";
    startBtn.style.background = "#f55036";
    startBtn.style.color = "white";
};

document.getElementById("editBtn").onclick = () => {
    const selected = profileList.value;
    if (!selected) return alert("Select profile ❌");
    const profiles = JSON.parse(localStorage.getItem("meesho_profiles") || "{}");
    capturing = true;
    capturedFields = (profiles[selected] || []).map(f => ({ ...f }));
    statusBox.innerText = "Editing...";
    countBox.innerText = `Captured: ${capturedFields.length}`;
    startBtn.innerText = "● Editing";
};

document.getElementById("saveBtn").onclick = () => {
    const name = document.getElementById("profileName").value.trim();
    if (!name) return alert("Enter profile name ❌");
    const toSave = capturedFields.map(f => ({ selector: f.selector, value: f.value, type: f.type || "text" }));
    const profiles = JSON.parse(localStorage.getItem("meesho_profiles") || "{}");
    profiles[name] = toSave;
    localStorage.setItem("meesho_profiles", JSON.stringify(profiles));
    capturing = false;
    statusBox.innerText = "Saved ✅";
    startBtn.innerText = "Start Capture";
    startBtn.style.background = "";
    startBtn.style.color = "";
    loadProfiles();
};

document.getElementById("editSaveBtn").onclick = () => {
    const selected = profileList.value;
    if (!selected) return alert("Select profile ❌");
    const profiles = JSON.parse(localStorage.getItem("meesho_profiles") || "{}");
    const oldData = profiles[selected] || [];
    const merged = [...oldData];
    capturedFields.forEach(n => {
        const ex = merged.find(f => f.selector === n.selector);
        if (ex) { ex.value = n.value; ex.type = n.type || ex.type || "text"; }
        else merged.push({ selector: n.selector, value: n.value, type: n.type || "text" });
    });
    profiles[selected] = merged;
    localStorage.setItem("meesho_profiles", JSON.stringify(profiles));
    capturing = false;
    statusBox.innerText = "Edit Saved ✅";
    countBox.innerText = `Captured: ${merged.length}`;
    startBtn.innerText = "Start Capture";
    startBtn.style.background = "";
    startBtn.style.color = "";
};

// =========================
// AUTOFILL - REACT COMPATIBLE (FIXED)
// =========================
document.getElementById("runBtn").onclick = async () => {
    const selected = profileList.value;
    if (!selected) return alert("Select profile ❌");
    const profiles = JSON.parse(localStorage.getItem("meesho_profiles") || "{}");
    const data = profiles[selected];
    if (!data || !data.length) return alert("Empty profile ❌");
    statusBox.innerText = "Filling...";

    // Har selector ka occurrence track karo
    const selectorIndexMap = {};

    for (const f of data) {
        if (selectorIndexMap[f.selector] === undefined) selectorIndexMap[f.selector] = 0;
        const targetIndex = selectorIndexMap[f.selector];
        selectorIndexMap[f.selector]++;

        let el = null;
        for (let i = 0; i < 20; i++) {
            try {
                const all = document.querySelectorAll(f.selector);
                el = all[targetIndex] || all[0] || null;
            } catch(e) {
                const idMatch = f.selector.match(/^#(.+)$/);
                if (idMatch) {
                    const rawId = idMatch[1].replace(/\\(.)/g, "$1");
                    el = document.getElementById(rawId);
                }
            }
            if (el) break;
            await sleep(400);
        }
        if (!el) { console.warn("Field not found:", f.selector); continue; }

        el.scrollIntoView({ block: "center" });
        await sleep(300);

        const fieldType = f.type || "text";

        if (fieldType === "dropdown") {
            await fillDropdown(el, f.value);
        } else {
            await reactFill(el, f.value);
        }

        await sleep(500);

        // Variant row add karo agar same selector aur bhi baaki hai
        const currentIdx = selectorIndexMap[f.selector] - 1;
        const totalSame = data.filter(x => x.selector === f.selector).length;
        if (currentIdx < totalSame - 1) {
            const addBtns = Array.from(document.querySelectorAll('button, span[role="button"]')).filter(btn => {
                const t = btn.innerText.trim().toLowerCase();
                return (t === "+" || t === "add" || t.includes("add size") || t.includes("add variant") || t.includes("row add") || t.includes("jodein") || t.includes("add more"));
            });
            if (addBtns.length > 0) {
                addBtns[addBtns.length - 1].click();
                await sleep(800);
            }
        }
    }
    statusBox.innerText = "Done 🚀";
};

// Dropdown fill helper
async function fillDropdown(el, value) {
    el.click();
    await sleep(700);

    // MUI/custom dropdowns
    const options = Array.from(document.querySelectorAll(
        '[role="option"], li[class*="option"], li[class*="MuiMenuItem"], li[class*="item"], [role="listbox"] li, [data-value]'
    ));

    let match = options.find(opt => opt.innerText.trim().toLowerCase() === value.trim().toLowerCase());
    if (!match) match = options.find(opt => opt.innerText.trim().toLowerCase().includes(value.trim().toLowerCase()));
    if (!match) match = options.find(opt => opt.innerText.trim().toLowerCase().startsWith(value.trim().toLowerCase()));

    if (match) {
        match.scrollIntoView({ block: "center" });
        await sleep(200);
        match.click();
        await sleep(300);
        return;
    }

    // Native select fallback
    if (el.tagName === "SELECT") {
        const opts = Array.from(el.options);
        let nativeMatch = opts.find(o => o.text.trim().toLowerCase() === value.trim().toLowerCase());
        if (!nativeMatch) nativeMatch = opts.find(o => o.text.trim().toLowerCase().includes(value.trim().toLowerCase()));
        if (nativeMatch) {
            el.value = nativeMatch.value;
            el.dispatchEvent(new Event("change", { bubbles: true }));
            el.dispatchEvent(new Event("input",  { bubbles: true }));
        }
    }
}

// =========================
// REACT-COMPATIBLE FILL (FIXED - blur order correct)
// =========================
async function reactFill(el, value) {
    // contenteditable div support
    if (el.getAttribute && el.getAttribute("contenteditable") === "true") {
        el.focus();
        await sleep(50);
        el.innerText = value;
        el.dispatchEvent(new Event("input",  { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(100);
        el.dispatchEvent(new Event("blur",   { bubbles: true }));
        return;
    }

    el.focus();
    await sleep(80);

    // React ke native setter use karo
    const proto = el.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
    const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;

    if (nativeSetter) {
        nativeSetter.call(el, value);
    } else {
        el.value = value;
    }

    // Events sahi order mein fire karo (blur LAST mein)
    el.dispatchEvent(new Event("input",   { bubbles: true }));
    el.dispatchEvent(new Event("change",  { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keydown",  { bubbles: true, key: "a" }));
    el.dispatchEvent(new KeyboardEvent("keypress", { bubbles: true, key: "a" }));
    el.dispatchEvent(new KeyboardEvent("keyup",    { bubbles: true, key: "a" }));

    await sleep(150);

    // Verify karo value set hua ya nahi
    if (el.value !== value) {
        // React 18 ke liye - nativeInputValueSetter se dobara try
        if (nativeSetter) nativeSetter.call(el, value);
        el.dispatchEvent(new Event("input",  { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(100);
    }

    // Blur sabse last mein (pehle blur se React state reset hoti thi)
    el.dispatchEvent(new Event("blur", { bubbles: true }));
}

// =========================
// INSTANT CAPTURE - SAB KUCH (FIXED)
// =========================

// Capture map: selector -> {value, type, count} — duplicate avoid karne ke liye
function getCaptureKey(selector, el) {
    // Same element ke liye unique key
    return selector + "__" + (el ? (el.name || el.placeholder || el.id || "") : "");
}

// ---- Text / Textarea Capture ----
function handleTextCapture(e) {
    if (!capturing) return;
    const el = e.target;
    if (!el) return;
    if (!["INPUT", "TEXTAREA"].includes(el.tagName)) return;
    if (el.type === "checkbox" || el.type === "radio" || el.type === "file" || el.type === "hidden") return;
    if (panel.contains(el)) return;

    const selector = getSelector(el);
    if (!selector) return;

    const val = el.value.trim();
    if (!val) return;

    // Same element already captured hai toh sirf value update karo
    const existing = capturedFields.find(f => f._el === el);
    if (existing) {
        existing.value = val;
    } else {
        capturedFields.push({ selector, value: val, type: "text", _el: el });
        countBox.innerText = `Captured: ${capturedFields.length}`;
    }
    flashStatus("✅ Captured!");
}

// ---- Dropdown Capture ----
const dropdownObserver = new MutationObserver((mutations) => {
    if (!capturing) return;
    for (const mutation of mutations) {
        if (mutation.type === "attributes" && mutation.attributeName === "aria-selected") {
            const node = mutation.target;
            if (node.getAttribute("aria-selected") === "true" && !panel.contains(node)) {
                captureDropdownOption(node);
            }
        }
    }
});

dropdownObserver.observe(document.body, {
    subtree: true,
    attributes: true,
    attributeFilter: ["aria-selected"]
});

document.addEventListener("click", (e) => {
    if (!capturing) return;
    if (panel.contains(e.target)) return;

    const el = e.target;

    // Option element clicked?
    const option = el.closest('[role="option"]')
        || el.closest('li[class*="MuiMenuItem"]')
        || el.closest('li[class*="option"]')
        || el.closest('[data-value]');

    if (option) {
        // Thoda wait karo taaki DOM update ho
        setTimeout(() => captureDropdownOption(option), 100);
        return;
    }

    // Native select
    if (el.tagName === "SELECT") {
        setTimeout(() => {
            const selector = getSelector(el);
            if (!selector) return;
            const val = el.options[el.selectedIndex]?.text?.trim() || el.value?.trim();
            if (!val) return;
            const existing = capturedFields.find(f => f._el === el);
            if (existing) { existing.value = val; }
            else { capturedFields.push({ selector, value: val, type: "dropdown", _el: el }); countBox.innerText = `Captured: ${capturedFields.length}`; }
            flashStatus("✅ Dropdown Captured!");
        }, 100);
        return;
    }

    // Readonly input (custom dropdown trigger) - value change ka wait karo
    if (el.tagName === "INPUT" && el.readOnly) {
        setTimeout(() => {
            const selector = getSelector(el);
            if (!selector) return;
            const val = el.value?.trim();
            if (!val) return;
            const existing = capturedFields.find(f => f._el === el);
            if (existing) { existing.value = val; }
            else { capturedFields.push({ selector, value: val, type: "dropdown", _el: el }); countBox.innerText = `Captured: ${capturedFields.length}`; }
            flashStatus("✅ Dropdown Captured!");
        }, 600);
    }
}, true);

function captureDropdownOption(optionEl) {
    const val = optionEl.innerText?.trim() || optionEl.getAttribute("data-value");
    if (!val) return;

    let triggerEl = null;

    // aria-controls/aria-owns se trigger input dhundho
    const listbox = optionEl.closest('[role="listbox"]');
    if (listbox) {
        const listboxId = listbox.id;
        if (listboxId) {
            triggerEl = document.querySelector(`[aria-controls="${listboxId}"], [aria-owns="${listboxId}"]`);
        }
        if (!triggerEl) {
            const parent = listbox.parentElement;
            if (parent) {
                triggerEl = parent.querySelector('input[aria-autocomplete], input[aria-expanded]')
                    || parent.querySelector('input')
                    || parent.previousElementSibling?.querySelector('input')
                    || parent.previousElementSibling;
            }
        }
    }

    // Focused element fallback
    if (!triggerEl) {
        const focused = document.activeElement;
        if (focused && !panel.contains(focused) && ["INPUT", "TEXTAREA", "DIV"].includes(focused.tagName)) {
            triggerEl = focused;
        }
    }

    if (!triggerEl) return; // selector nahi mila toh skip

    const selector = getSelector(triggerEl);
    if (!selector) return;

    const existing = capturedFields.find(f => f._el === triggerEl);
    if (existing) { existing.value = val; }
    else { capturedFields.push({ selector, value: val, type: "dropdown", _el: triggerEl }); countBox.innerText = `Captured: ${capturedFields.length}`; }

    flashStatus("✅ Dropdown Captured!");
}

document.addEventListener("change", (e) => {
    if (!capturing) return;
    if (panel.contains(e.target)) return;
    const el = e.target;
    if (el.tagName === "SELECT") {
        const selector = getSelector(el);
        if (!selector) return;
        const val = el.options[el.selectedIndex]?.text?.trim() || el.value?.trim();
        if (!val) return;
        const existing = capturedFields.find(f => f._el === el);
        if (existing) { existing.value = val; }
        else { capturedFields.push({ selector, value: val, type: "dropdown", _el: el }); countBox.innerText = `Captured: ${capturedFields.length}`; }
        flashStatus("✅ Captured!");
    }
}, true);

document.addEventListener("input", handleTextCapture, true);
document.addEventListener("focusout", (e) => {
    if (!capturing) return;
    const el = e.target;
    if (!el || !["INPUT", "TEXTAREA"].includes(el.tagName)) return;
    if (panel.contains(el)) return;
    handleTextCapture(e);
}, true);

// Flash status helper
let flashTimer = null;
function flashStatus(msg) {
    statusBox.innerText = msg;
    if (flashTimer) clearTimeout(flashTimer);
    flashTimer = setTimeout(() => {
        statusBox.innerText = capturing ? "Capturing..." : "Idle";
    }, 1200);
}

// =========================
// SEO AI - GROQ (100% FREE)
// =========================
document.getElementById("seoGenerateBtn").onclick = async () => {
    const doTitle = document.getElementById("seoTitleCheck").checked;
    const doDesc  = document.getElementById("seoDescCheck").checked;
    const brand   = document.getElementById("seoBrand").value.trim();
    const keyword = document.getElementById("seoKeyword").value.trim();
    const seoStatus = document.getElementById("seoStatus");

    if (!doTitle && !doDesc) { seoStatus.innerText = "❌ Koi ek checkbox select karo"; return; }
    if (!keyword)             { seoStatus.innerText = "❌ Product keyword daalo"; return; }

    const apiKey = "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";

    seoStatus.innerText = "⏳ AI likh raha hai...";

    let parts = [];
    if (doTitle) parts.push(
        `You are a Meesho product listing expert. Create a professional SEO title for this product keyword: "${keyword}"\n\n` +
        `STRICT RULES for title:\n` +
        `- NEVER copy the keyword as-is into the title\n` +
        `- Interpret shorthand properly: "x2" or "x 2" = Pack of 2, "x3" or "x 3" = Pack of 3, "250ml" = 250 ml, etc.\n` +
        `- Write a clean, natural, buyer-friendly title like a real product name\n` +
        `- Include: brand/product name, key feature, size/quantity in proper format, variant if any\n` +
        `- Example input: "dishwash 250 x 3" → Example output: "Dishwash Liquid 250ml - Pack of 3 | Lemon Dish Cleaning Gel"\n` +
        `- Example input: "kurti xl cotton" → Example output: "Women Cotton Kurti XL | Casual Daily Wear Kurta"\n` +
        `- If brand name is provided, put it at the start of the title\n` +
        `- Brand name: "${brand || 'none (skip it)'}"\n` +
        `- Max 60 characters\n` +
        `- English only, no shorthand, no "x3" style — write it out properly\n` +
        `Label exactly: SEO_TITLE: <title>`
    );
    if (doDesc) parts.push(
        `Write an SEO product description for Meesho listing of: "${keyword}". ` +
        `150-200 words. English. Include features, material, use cases, natural keywords. ` +
        `Label exactly: SEO_DESC: <description>`
    );
    const prompt = parts.join("\n\n") + "\n\nRespond ONLY with the labeled output. No extra text.";

    try {
        const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
            body: JSON.stringify({
                model: "llama-3.3-70b-versatile",
                max_tokens: 600,
                messages: [
                    { role: "system", content: "You are an expert Meesho product listing writer. You always interpret product keywords intelligently — never copy shorthand like x3 or 250ml directly into title. Convert them into natural professional product titles. Follow all instructions exactly." },
                    { role: "user",   content: prompt }
                ]
            })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            if (res.status === 401) {
                seoStatus.innerText = "❌ API Key galat hai. Dobara enter hoga.";
                await chrome.storage.local.remove("groq_api_key");
                return;
            }
            seoStatus.innerText = `❌ Error ${res.status}: ${err.error?.message || "API error"}`;
            return;
        }

        const data   = await res.json();
        const aiText = data.choices?.[0]?.message?.content || "";
        if (!aiText) { seoStatus.innerText = "❌ Response nahi aaya. Dobara try karo."; return; }

        let filledAny = false;
        if (doTitle) {
            const m = aiText.match(/SEO_TITLE:\s*(.+)/i);
            if (m) {
                const title = m[1].trim().replace(/^["'*`]+|["'*`]+$/g, "");
                const ok = await fillMeeshoField("title", title);
                filledAny = filledAny || ok;
                if (!ok) seoStatus.innerText = `📋 Title (copy karo): ${title}`;
            }
        }
        if (doDesc) {
            const m = aiText.match(/SEO_DESC:\s*([\s\S]+)/i);
            if (m) {
                const desc = m[1].trim().replace(/^["'*`]+|["'*`]+$/g, "");
                const ok = await fillMeeshoField("description", desc);
                filledAny = filledAny || ok;
                if (!ok) seoStatus.innerText += "\n⚠️ Description field nahi mila — manually paste karo.";
            }
        }
        if (filledAny) seoStatus.innerText = "✅ SEO Content fill ho gaya! 🎉";

    } catch (err) {
        console.error(err);
        seoStatus.innerText = `❌ Network error: ${err.message}`;
    }
};

async function fillMeeshoField(fieldType, value) {
    const selectors = fieldType === "title"
        ? [
            "input[name*='title' i]",
            "input[placeholder*='title' i]",
            "input[placeholder*='product name' i]",
            "input[placeholder*='name' i]",
            "textarea[name*='title' i]",
            "input[class*='title' i]",
            "input[aria-label*='title' i]"
          ]
        : [
            "textarea[name*='description' i]",
            "textarea[placeholder*='description' i]",
            "textarea[aria-label*='description' i]",
            "div[role='textbox'][aria-label*='description' i]",
            "div[role='textbox'][contenteditable='true']",
            "[contenteditable='true']",
            "textarea"
          ];

    for (const sel of selectors) {
        try {
            const el = document.querySelector(sel);
            if (!el) continue;
            el.scrollIntoView({ block: "center" });
            await sleep(250);
            await reactFill(el, value);
            // Verify
            await sleep(200);
            const filled = el.value || el.innerText || "";
            if (filled.trim()) return true;
        } catch(e) { continue; }
    }
    return false;
}

// =========================
// SELECTOR GENERATOR
// =========================
function getSelector(el) {
    if (!el) return null;
    // ID-based (MUI dynamic IDs skip karo)
    if (el.id && !el.id.match(/^(mui-|:r|:[a-z][0-9])/i)) {
        return `#${CSS.escape(el.id)}`;
    }
    // Name-based
    if (el.name) return `[name="${el.name}"]`;
    // aria-label
    if (el.getAttribute && el.getAttribute("aria-label")) {
        return `[aria-label="${el.getAttribute("aria-label")}"]`;
    }
    // placeholder
    if (el.placeholder) {
        return `[placeholder="${el.placeholder}"]`;
    }
    // data-testid
    if (el.getAttribute && el.getAttribute("data-testid")) {
        return `[data-testid="${el.getAttribute("data-testid")}"]`;
    }
    // Class-based fallback
    if (el.className && typeof el.className === "string") {
        const cls = el.className.trim().split(/\s+/)[0];
        if (cls && !cls.includes(":") && !cls.match(/^css-/)) {
            return `${el.tagName.toLowerCase()}.${cls}`;
        }
    }
    return null;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

} // end startTool
